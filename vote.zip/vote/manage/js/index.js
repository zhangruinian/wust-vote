$(function() {
    // 焦点轮播图设置
	myFocus.set({
	//ID
	id:'picBox',
	// pattern:'mF_fancy'//风格
	pattern:'mF_fancy'
	});
	myFocus.set({
	id:'picBox1',
	pattern:'mF_taobao2010'
	});
    
    //左侧Tab选项卡
	// $('.rightcontent > div:not(:first)').hide();
	// $('.leftsidebar > li').click(function(event) {
	//     event.preventDefault();
	// 	$('.rightcontent > div').hide();
	// 	$('.leftsidebar .active').removeClass("active");
	// 	$(this).addClass('active');   
	// 	var clicked = $(this).find('a:first').attr('href');
	// 	$('.rightcontent ' + clicked).fadeIn('fast');
	// }).eq(0).addClass('active');
   
	//列表右边内容的li的超过的部分添加省略号……
	var centerli=$(".content .lectureList li a");
	centerli.each(function(index,element){
		var text=centerli.eq(index).text();
		var strText=text.substr(0,25)+"...";
		$(this).text(strText);
	});
	//
	var centerli1=$(".labInform ul li a");
	centerli1.each(function(index,element){
		var text1=centerli1.eq(index).text();
		if(text1.length<=10){
			var strText1=text1.substr(0,10)+"...";
		};
		$(this).text(strText1);
	});

});