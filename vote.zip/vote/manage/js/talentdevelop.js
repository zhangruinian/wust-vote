//删除操作
function dodelete(id) {
	if (confirm("确定删除该用户吗？")) {
		var url = "TalentDevelopServlet?action=delete&id=" + id;
		// 使用$.post方式
		$.post(url, // 服务器要接受的url
		function(data) { // 服务器返回后执行的函数 参数 data保存的就是服务器发送到客户端的数据

			// 就是root对应的值这里是result!!
			var member = eval("(" + data + ")"); // 包数据解析为json 格式
			if (member.result == "success") {
				alert("删除成功");
				location.replace(location.href);
				return;
			}
		},

		"text" // 数据传递的类型 text

		);
	}
}

// 添加操作
function doadd() {
	var name = $("#name").val();
	var yjfx = $("#yjfx").val();

	if (name == "") {
		alert("姓名不能为空");
		return;
	}
	if (yjfx == "") {
		alert("研究方向不能为空");
		return;
	}

	var url = "TalentDevelopServlet?action=addtalent";
	// 使用$.post方式
	$.post(url, // 服务器要接受的url
	$("#talentform").serializeArray(), // 传递的参数
	function(data) { // 服务器返回后执行的函数 参数 data保存的就是服务器发送到客户端的数据

		// 就是root对应的值这里是result!!
		var member = eval("(" + data + ")"); // 包数据解析为json 格式
		if (member.result == "success") {
			alert("添加成功");
			location.replace(location.href);
			return;
		}
	},

	"text" // 数据传递的类型 text

	);
}