$(function() {
    // 焦点轮播图设置
	myFocus.set({
	//ID
	id:'picBox',
	// pattern:'mF_fancy'//风格
	pattern:'mF_fancy'
	});
	myFocus.set({
	id:'picBox1',
	
	pattern:'mF_YSlider'
	
	});
    
    //左侧Tab选项卡
	// $('.rightcontent > div:not(:first)').hide();
	// $('.leftsidebar > li').click(function(event) {
	//     event.preventDefault();
	// 	$('.rightcontent > div').hide();
	// 	$('.leftsidebar .active').removeClass("active");
	// 	$(this).addClass('active');   
	// 	var clicked = $(this).find('a:first').attr('href');
	// 	$('.rightcontent ' + clicked).fadeIn('fast');
	// }).eq(0).addClass('active');
   
	//列表右边内容的li的超过的部分添加省略号……
	var centerli=$(".content .lectureList li a");
	centerli.each(function(index,element){
		var text=centerli.eq(index).text();
		if(text.length>=25){
			var strText=text.substr(0,25)+"...";
		};
		$(this).text(strText);
	});
	//列表右边内容的li的超过的部分添加省略号……
	var centerli2=$(".conTop .labInform ul li a");
	centerli2.each(function(index,element){
		var text2=centerli2.eq(index).text();
		if(text2.length>=10){
			var strText2=text2.substr(0,10)+"...";
		};
		$(this).text(strText2);
	});

});