/**
 *
 * @authors kaychen (you@example.org)
 * @date    2015-11-24 16:44:34
 * @version $Id$
 */
if (window != top)
    top.location.href = location.href;

$(function() {


    $(document).onkeydown = function(ev) {
        var ev = window.event || ev;
        if (ev.keyCode == 13) {
            $('#form1').submit();
        }
    }

    $("#user_t").focus(function() {
        $(".login-i").css("backgroundPosition", "0px -48px");
        $(".pwd").css("backgroundPosition", "-48px 0px");
        $(this).hide();
        $("#username").show();
        $("#username").focus();
        $(".mes-back").html("");
    });

    $("#username").blur(function() {
        var v = $(this).val();
        if (v == "") {
            $(this).hide();
            $("#user_t").show();
        } else {
            $("#msg").hide();
        }
        $(".mes-back").html("");
    });



    $("#pwd_t").focus(function() {
        $(".login-i").css("backgroundPosition", "0px 0px");
        $(".pwd").css("backgroundPosition", "-48px -48px");
        $(this).hide();
        $("#password").show();
        $("#password").focus();
        $(".mes-back").html("");
    })

    $("#password").blur(function() {
        var v = $(this).val();
        if (v == "") {
            $(this).hide();
            $("#pwd_t").show();
        }
        $(".mes-back").html("");
    })



    $("input[name='password']").blur(function() {
        var v = $(this).val();
        if (v == "") {
            $("#mm_span").text("请输入密码(Password)");
        } else {
            $("#mm_span").text("");
        }
    })

    $("#form1").submit(function() {
        /*
        var usertype = "";
        $("input[name='usertype']").each(function(){
            if($(this).attr("checked")==true){
                usertype = $(this).val();
            }
        })

        if(usertype==""){
            alert("请选择您的身份类型");
            return false;
        }

        if(usertype!="xs"&&usertype!="jg"&&usertype!="uid"){
            alert("请选择有效的身份类型");
            return false;
        }
        */

        var username = $("input[name='username']").val();
        if (username == "") {
            // alert("管理员/注册账号)");
            $(".login-i").css("backgroundPosition", "0px -96px");
            $(".pwd").css("backgroundPosition", "-48px 0px");
            $(".mes-back").html("请输入有效的管理员/注册账号").insertAfter($(".login-i")[0]);
            $("input[name='username']").focus();
            return false;
        }

        var reg = /^[A-Za-z0-9]+$/;
        if (!reg.test(username)) {
            var reg2 = /^\w+((-\w+)|(\.\w+))*\@[A-Za-z0-9]+((\.|-)[A-Za-z0-9]+)*\.[A-Za-z0-9]+$/; //邮箱格式
            if (!reg2.test(username)) {
                // alert("请输入有效的管理员/注册账号");
                $(".login-i").css("backgroundPosition", "0px -96px");
                $(".pwd").css("backgroundPosition", "-48px 0px");
                $(".mes-back").html("请输入有效的管理员/注册账号").insertAfter($(".login-i")[0]);
                $("input[name='username']").focus();
                return false;
            }
        }

        var password = $("input[name='password']").val();
        if (password == "") {
            // alert("请输入用户密码(Password)");
            $(".login-i").css("backgroundPosition", "0px 0px");
            $(".pwd").css("backgroundPosition", "-48px -96px");
            $(".mes-back").html("请输入用户密码(Password)").insertAfter($(".pwd"));
            $("input[name='password']").focus();
            return false;
        }
        $("input[name='password']").val($.base64.encode(password));
    })
})
